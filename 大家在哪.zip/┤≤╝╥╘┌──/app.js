var Bmob = require("utils/Bmob-1.6.1.min.js");
Bmob.initialize("f21ff9220ec6974b82086e253ca3e4ff", "d84a395a028374b966a6ac420bc935af");